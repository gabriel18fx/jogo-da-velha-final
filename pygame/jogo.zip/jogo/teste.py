vez = "X"
rodada = 0

while True:
    
    if(vez == "X"):
        int(ino)
        print("Vez de X")
        vez = "O"
        rodada = rodada + 1
    elif(vez == "O"):
        print("Vez da O")
        vez = "X"
        rodada = rodada + 1

    
    if(rodada >= 9):
        break